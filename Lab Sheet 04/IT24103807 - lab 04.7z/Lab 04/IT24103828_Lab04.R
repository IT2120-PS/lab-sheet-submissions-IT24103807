getwd()
setwd("C:\\Users\\it24103807\\Desktop\\Lab 04")

#Q1
branch_data <- read.table("C:\\Users\\it24103807\\Desktop\\Lab 04\\Exercise.txt", header=TRUE, sep=",")
head(branch_data)

#Q2
str(branch_data)


#Q3
boxplot(branch_data$Sales_X1, main="Box plot for Sales", ylab = "Sales")

#Q4 
fivenum(branch_data$Advertising_X2)  

IQR(branch_data$Advertising_X2)

#Q5 
find_outliers <- function(x){
  q1 <- quantile(x , 0.25)
  q3 <- quantile(x , 0.75)
  IQR_value <- q3 - q1
  lower <- q1 - 1.5 * IQR_value
  upper <- q3 + 1.5 * IQR_value
  outliers <- x[x < lower | x > upper]
  return(outliers)
}

find_outliers(branch_data$Years_X3)
