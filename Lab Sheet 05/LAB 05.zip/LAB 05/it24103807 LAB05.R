setwd("C:\\Users\\it24103807\\Desktop\\Lab 05")

delivery_times <- read.table("Exercise - Lab 05.txt", header = TRUE)
names(delivery_times) <- c("DeliveryTime")
head(delivery_times)

breaks <- seq(20, 70, length.out = 10)
hist(delivery_times$DeliveryTime,
     breaks = breaks,
     right = FALSE,                      
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time (minutes)",
     col = "red",
     border = "black")

hist_data <- hist(delivery_times$DeliveryTime,
                  breaks = breaks,
                  right = FALSE,
                  plot = FALSE)

cum_freq <- cumsum(hist_data$counts)
plot(hist_data$breaks[-1], cum_freq, type = "o",
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency",
     col = "red", pch = 16)
